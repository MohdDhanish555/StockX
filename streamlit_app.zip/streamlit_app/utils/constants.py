SCOPE = "https://www.googleapis.com/auth/spreadsheets"
SPREADSHEET_ID = "1rkMVLvh3JrBq_tbi4Ho0qjCDAP3vYdNuWOEjYpkJLNU"
SHEET_NAME = "Database"
GSHEET_URL = f"https://docs.google.com/spreadsheets/d/{SPREADSHEET_ID}"
COMMENT_TEMPLATE_MD = """{} - {}
> {}"""